import java.util.ArrayList;
import java.util.HashSet;

import static java.lang.Math.pow;

public class Triangle extends Polygon {
    public Triangle(Integer... args){
        super(args);
    }
    /**
     * calculate perimeter
     * @param args sides
     * @return perimeter
     */
    @Override
    public double CalculatePerimeter(Integer... args) {
        ArrayList<Integer> sides;
        sides=super.getSide();
        double sum = 0;
        for (int j=0 ;j<sides.size()-1;j++) {
            sum +=sides.get(j);
        }
        return sum;

    }
    /**
     * calculate area
     * @param args sides
     * @return area
     */
    @Override
    public double CalculateArea(Integer... args) {
        ArrayList<Integer> sides;
        sides=super.getSide();
        double jn = CalculatePerimeter(args) / 2;
        double area =  pow(jn * ( jn - sides.get(0) ) * ( jn - sides.get(1) ) * ( jn - sides.get(2) ),0.5);
        return area;
    }
    /**
     * check three sides is same or not
     * @return boolean
     */
    public boolean isEquilateral(){
        ArrayList<Integer> sides;
        sides=super.getSide();
        HashSet<Integer> side = new HashSet<>(sides);
        return side.size() == 1;
    }
    @Override
    public String toString() {
        return "Triangle:{"+super.toString()+"  Area: "+CalculateArea()+"  Perimeter: "+CalculatePerimeter()+" }";
    }

    /**
     * print info
     */
    @Override
    public void draw() {
        System.out.println(this.toString());
    }


}