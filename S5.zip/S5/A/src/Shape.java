abstract public class Shape  {

    abstract public double CalculatePerimeter(Integer... args);

   abstract public double CalculateArea(Integer... args);

   abstract public void draw();
}
