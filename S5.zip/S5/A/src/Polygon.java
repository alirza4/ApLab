import java.util.ArrayList;
import java.util.Collections;

abstract public class Polygon extends Shape {
    private ArrayList<Integer> side;
    public Polygon(Integer... args){
        side=new ArrayList<>();
        Collections.addAll(side, args);
    }
    public ArrayList<Integer> getSide() {
        return side;
    }

    @Override
    public String toString() {
        String jn="";
        int j=1;
        for (Integer n:side
        ) {
            jn+="  side"+j+":"+n;
            j++;

        }
        return jn;
    }
}
