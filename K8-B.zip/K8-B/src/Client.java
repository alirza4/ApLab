import java.io.*;
import java.net.*;
import java.util.*;

public class Client {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        try( Socket socket=new Socket("localhost" , 4404); DataInputStream input=new DataInputStream(socket.getInputStream()); DataOutputStream output=new DataOutputStream(socket.getOutputStream())){
            String string;
            while(true){
                string=scanner.nextLine();
                if (string.equals("Over")) break;
                output.writeUTF(string);
                System.out.println("----> "+ input.readUTF());
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}