import java.util.ArrayList;
import java.util.HashSet;

public class Rectangle extends Polygon {
    public Rectangle(Integer... args){
        super(args);
    }
    /**
     * calculate perimeter
     * @param args sides
     * @return perimeter
     */
    @Override
    public double CalculatePerimeter(Integer... args) {
        ArrayList<Integer> sides;
        sides=super.getSide();
        double perimeter = 0;
        for (int j=0;j<sides.size()-1;j++) {
            perimeter +=sides.get(j);
        }
        return perimeter;
    }
    /**
     * calculate area
     * @param args sides
     * @return area
     */
    @Override
    public double CalculateArea(Integer... args) {
        ArrayList<Integer> sides;
        sides=super.getSide();
        HashSet<Integer> side = new HashSet<>(sides);
        double area = 1;
        for (Integer j : side) {
            area *= j;
        }
        return area;
    }
    /**
     * check rectangle is square or not
     * @return boolean
     */
    public boolean isSquare() {
        ArrayList<Integer> sides;
        sides=super.getSide();
        HashSet<Integer> side = new HashSet<>(sides);
        return side.size() == 1;
    }


    @Override
    public String toString() {
        return "Rectangle:{"+super.toString()+"  Area: "+CalculateArea()+"  Perimeter: "+CalculatePerimeter()+" }";
    }

    /**
     * print info
     */
    @Override
    public void draw() {
        System.out.println(this.toString());

    }


}
