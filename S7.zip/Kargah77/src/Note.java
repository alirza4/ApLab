import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Note {
    ArrayList<String> noteNames=new ArrayList<>();
    Scanner scanner=new Scanner(System.in);
    public void addF() {
        System.out.println("plz enter file name");
        String name=scanner.nextLine();
        System.out.println("plz enter text");
        String text=scanner.nextLine();
        byte T[]=text.getBytes();
        try( FileOutputStream fout=new FileOutputStream(name)){
            fout.write(T);
            noteNames.add(name);
        }
        catch(Exception ex){
            System.out.println(ex);}
    }
    public void readF(int N) {
        try( FileInputStream fin=new FileInputStream(noteNames.get(N))){
         int j;
            System.out.print("note name: "+noteNames.get(N)+" text:" );
            while((j=fin.read())!=-1){
                System.out.print((char)j);
            }
        }catch(Exception ex)
        {System.out.println(ex);}
    }
    public void addB(){
        System.out.println("plz enter file name");
        String name=scanner.nextLine();
        System.out.println("plz enter text");
        String text=scanner.nextLine();
        try (BufferedWriter Bw = new BufferedWriter(new FileWriter(name))) {
            Bw.write(text);
            noteNames.add(name);
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
    public void readB(int N){
        try(BufferedReader Br=new BufferedReader(new FileReader(noteNames.get(N)))){
            int j;
            System.out.print("note name: "+noteNames.get(N)+" text:" );
            while((j=Br.read())!=-1){
                System.out.print((char)j);
            }
        }
        catch (Exception ex){
            System.out.println(ex);
        }
    }
    public void readAll(){
        for (int j=0;j<noteNames.size();j++){
            try(FileInputStream fin=new FileInputStream(noteNames.get(j))) {
                int jn;
                System.out.print("note name: "+noteNames.get(j)+" text: ");
                while((jn=fin.read())!=-1){
                    System.out.print((char)jn);
                }
                System.out.println();
            }catch(Exception ex)
            {System.out.println(ex);}
        }
    }
    public void Delete(int N){
        File file = new File(noteNames.get(N));
        try{
            if(file.delete()){
                System.out.println(file.getName() + " is deleted!");
                noteNames.remove(N);
            }else{
                System.out.println("Delete failed: File didn't delete");
            }
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
    public void printnotes(){
        for (int jn=0;jn<noteNames.size();jn++){
            System.out.println(jn+1+") "+noteNames.get(jn));
        }

    }

}

