import java.util.ArrayList;

public class Paint {
    private ArrayList<Shape> shapes;

    public Paint() {
        shapes = new ArrayList<>();
    }
    public void addShape(Shape shape) {
        shapes.add(shape);
    }

    /**
     * print all type of shape's info
     */
    public void drawAll() {
        for (Shape i : shapes) {
            i.draw();
        }
    }

    /**
     * check if shapes square or equilateral print
     */
    public void describeEqualSides() {
        for (Shape j : shapes) {
            if (j instanceof Triangle) {
                Triangle triangle1 = (Triangle) j;
                if (triangle1.isEquilateral())
                    System.out.println("equilateral : "+triangle1.toString());
            }
            else if (j instanceof Rectangle) {
                Rectangle rectangle1 = (Rectangle) j;
                if (rectangle1.isSquare()) {
                    System.out.println("square : "+rectangle1.toString());
                }

            }

        }
    }
}