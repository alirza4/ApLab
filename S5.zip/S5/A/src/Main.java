public class Main {
    public static void main(String[] args) {
        Shape cir1 = new Circle(19);
        Shape cir2 = new Circle(3);
        Shape rec1 = new Rectangle(1,4,1,4);
        Shape rec2 = new Rectangle(5,5,5,5);
        Shape rec3 = new Rectangle(6,6,6,6);
        Shape tri1 = new Triangle(2,2,2);
        Shape tri2 = new Triangle(4,4,6);
        Paint paint = new Paint();
        paint.addShape(cir1);
        paint.addShape(cir2);
        paint.addShape(rec1);
        paint.addShape(rec2);
        paint.addShape(rec3);
        paint.addShape(tri1);
        paint.addShape(tri2);
        paint.drawAll();
        paint.describeEqualSides();
    }


}
