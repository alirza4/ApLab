import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
public class God {
    private static ArrayList<ClientHandler> Clients=new ArrayList<>();
    private static ArrayList<String> usernames=new ArrayList<>();
    private static ArrayList<String> CitizenTeam=new ArrayList<>();
    private static ArrayList<String> MafiaTeam=new ArrayList<>();
    private static ArrayList<Player> players=new ArrayList<>();
    private static int night=1;
    private static ExecutorService numP= Executors.newFixedThreadPool(10);
    private static ArrayList<String> rols= new ArrayList<>();
    public static void main(String[] args) throws IOException {
        ServerSocket server=new ServerSocket(1664);
        int num=1;
        rols.add("DoctorLecter");
        rols.add("GodFather");
       rols.add("SimpleMafia");
        rols.add("Doctor");
        rols.add("Detective");
        rols.add("HardDie");
//        rols.add("mayor");
//        rols.add("Psychologist");
//        rols.add("Citizen");
//        rols.add("professional");
        try{
            while (true){
            Socket socket=server.accept();
            System.out.println("Client number "+num+" Connected");
            num++;
            ClientHandler Clienthandler=new ClientHandler(players,socket,Clients,usernames,rols,CitizenTeam,MafiaTeam,night);
            Clients.add(Clienthandler);
            numP.execute(Clienthandler);
        }
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
class ClientHandler implements Runnable{
    private Socket client;
    private Player player;
    private ArrayList<Player>players;
    private ArrayList<ClientHandler> clients;
    private ArrayList<String> usernames;
    private ArrayList<String> Mteam;
    private ArrayList<String> Cteam;
    private ArrayList<String> rols;
    private DataInputStream input;
    private DataOutputStream output;
    private String name="";
    private String Rol="";
    private int night;
    private Random random=new Random();
    public ClientHandler(ArrayList<Player>players,Socket client,ArrayList<ClientHandler>clients, ArrayList<String> usernames,ArrayList<String> rols,ArrayList<String> Cteam,ArrayList<String> Mteam,int night) throws IOException {
        this.players=players;
        this.client = client;
        this.clients=clients;
        this.usernames=usernames;
        this.rols=rols;
        this.Cteam=Cteam;
        this.Mteam=Mteam;
        this.night=night;
        input = new DataInputStream(client.getInputStream());
        output = new DataOutputStream(client.getOutputStream());
    }
    @Override
    public void run() {
        try {
            String Str="";

            String rol="";
            boolean state=false;
            boolean NorD=true;
            while (true){
                    if (state && !NorD){
                        Str=input.readUTF();
                        for (ClientHandler Cl:clients){
                            Cl.output.writeUTF(name+" : "+Str);
                        }
                    }
                    if (state && NorD){
                        if (rol.equals("GodFather")){
                            int num=1;
                            for (String player:Cteam){
                                output.writeUTF(num+") " +player);
                                num++;
                            }

                            String choosen=input.readUTF();
                            int choosen1=Integer.parseInt(choosen);
                            output.writeUTF("ur choosen player is: "+Cteam.get(choosen1-1));
                            for (Player p:players){
                                if (p.getName().equals(Cteam.get(choosen1-1))){
                                    p.setAlive(false);
                                }
                            }
                            NorD=false;
                        }
                        if (rol.equals("DoctorLecter")){
                            int num=1;
                            for (String player:Cteam){
                                output.writeUTF(num+") " +player);
                                num++;
                            }
                            String choosen1=input.readUTF();
                            int choosen2=Integer.parseInt(choosen1);
                            output.writeUTF("ur choosen player is: "+Cteam.get(choosen2-1));
                            for (ClientHandler p:clients){
                                if (p.Rol.equals("GodFather")){
                                    p.output.writeUTF(name+"("+rol+")"+" choose "+Cteam.get(choosen2-1));
                                }
                            }
                            for (String player:Mteam){
                                output.writeUTF(num+") " +player);
                                num++;
                            }
                            output.writeUTF("plz choose :");
                            String choosen3=input.readUTF();
                            int choosen4=Integer.parseInt(choosen3);
                            output.writeUTF("ur choosen player is: "+Cteam.get(choosen2-1));
                            //...
                            NorD=false;
                        }
                        if (rol.equals("SimpleMafia")){
                            int num=1;
                            for (String player:Cteam){
                                output.writeUTF(num+") " +player);
                                num++;
                            }
                            String choosen=input.readUTF();
                            int choosen3=Integer.parseInt(choosen);
                            output.writeUTF("ur choosen player is: "+Cteam.get(choosen3-1));
                            for (ClientHandler p:clients){
                                if (p.name.equals("GodFather")){
                                    p.output.writeUTF(Cteam.get(choosen3-1));
                                }
                            }
                            NorD=false;
                        }
                        if (rol.equals("Doctor")){
                            int num=1;
                            for (String player:usernames){
                                output.writeUTF(num+") " +player);
                                num++;
                            }
                            String choosen=input.readUTF();
                            int choosen4=Integer.parseInt(choosen);
                            System.out.println(usernames.get(choosen4-1));
                            output.writeUTF("ur choosen player is: "+usernames.get(choosen4-1));
                            for (Player p:players){
                                if (p.getName().equals(usernames.get(choosen4-1))){
                                    p.setAlive(true);
                                }
                            }
                            NorD=false;
                        }
                        if (rol.equals("Detective")){
                            int num=1;
                            for (String player:usernames){
                                output.writeUTF(num+") " +player);
                                num++;
                            }
                            String choosen=input.readUTF();
                            int choosen5=Integer.parseInt(choosen);
                            output.writeUTF("ur choosen player is: "+usernames.get(choosen5-1));
                            for (Player p:players){
                                if (p.getName().equals(usernames.get(choosen5-1))){
                                    System.out.println("111");
                                    if (p.getRol().equals("SimpleMafia") || p.getRol().equals("DoctorLecter")){
                                        System.out.println("222");
                                        output.writeUTF(p.getName()+" Mafia");
                                    }
                                }
                            }
                            NorD=false;
                        }
                        if (rol.equals("professional")){
                            output.writeUTF("do u want to shot someone?!\n1)yes\n2)no");
                            String choosen1=input.readUTF();
                            int choosen2=Integer.parseInt(choosen1);
                            if (choosen2==1){
                                int num=1;
                                for (String player:usernames){
                                    output.writeUTF(num+") " +player);
                                    num++;
                                }
                                String choosen3=input.readUTF();
                                int choosen4=Integer.parseInt(choosen3);
                                boolean shot=false;
                                for (Player p:players){
                                    if (p.getName().equals(usernames.get(choosen4-1)) && (p.getRol().equals("SimpleMafia") || p.getRol().equals("DoctorLecter") || p.getRol().equals("GodFather")) ){
                                        p.setAlive(false);
                                        shot=true;
                                        break;
                                    }
                                }
                                if (shot==false){

                                }



                                //...
                            }
                        }
                        NorD=false;
                    }
                     if (!state){
                        output.writeUTF("Plz enter ur name");
                        name=input.readUTF();
                        state=true;
                        for (String sl:usernames){
                            if (name.equals(sl)){
                                state=false;
                                break;
                            }
                        }
                        if (state){
                            usernames.add(name);
                            int rand=random.nextInt(rols.size());
                            rol=rols.get(rand);
                            rols.remove(rand);
                            Rol=rol;
                            System.out.println(rol);
                            if (rol.equals("GodFather") || rol.equals("DoctorLecter") || rol.equals("SimpleMafia") ){
                                Mteam.add(name);
                            }
                            else {
                                Cteam.add(name);
                            }
                            player=new Player(name,rol);
                            players.add(player);
                            output.writeUTF(" ur name is ok and ur rol is "+rol+" now start chat");
                        }
                    }
                }
            }
        catch (Exception ex){
            ex.printStackTrace();
            System.out.println("55");
        }
        try {
            input.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
class Player {
    private String name;
    private String rol;
    private boolean alive;
    public Player( String name, String rol) {
        this.name = name;
        this.rol = rol;
        alive = true;
    }
    public String getName() {
        return name;
    }
    public String getRol() {
        return rol;
    }
    public boolean isAlive() {
        return alive;
    }
    public void setAlive(boolean alive) {
        this.alive = alive;}
}