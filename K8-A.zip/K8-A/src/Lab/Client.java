package Lab;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    Scanner scanner=new Scanner(System.in);
    public Client(){
        this.connect();
    }
    public void connect(){
        try(Socket channel = new Socket("localhost" , 4444) ;DataInputStream  indata=new DataInputStream(channel.getInputStream() ); DataOutputStream outdata=new DataOutputStream(channel.getOutputStream())) {
            while(true){
                String string=scanner.nextLine();
                if (string.equals("over")){
                    break;
                }
                outdata.writeUTF(string);
                System.out.println("--->: "+ indata.readUTF());
            }
            System.out.println("Program End");
        } catch (IOException ex) {
            ex.getStackTrace();
        }
    }
    public static void main(String[] args) {
        Client client=new Client();
        client.connect();
    }
}
