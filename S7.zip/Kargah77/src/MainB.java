
import java.util.Scanner;

public class MainB {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Note note=new Note();
        boolean state=true;
        while (state){
            System.out.println("\n1)Add\n2)Read\n3)ReadAll\n4)Delete\n5)Exit");
            int joon=scanner.nextInt();
            switch (joon){
                case 1:
                    note.addB();
                    break;
                case 2:
                    if (note.noteNames.size()==0){
                        System.out.print("u dont have any note");
                        break;
                    }
                    else
                    note.printnotes();
                    System.out.println("plz enter your note:");
                    int jn=scanner.nextInt();
                    note.readB(jn-1);
                    break;
                case 3:
                    if (note.noteNames.size()==0){
                        System.out.print("u dont have any note");
                        break;
                    }
                    else
                    note.readAll();
                    break;
                case 4:
                    if (note.noteNames.size()==0){
                        System.out.print("u dont have any note");
                        break;
                    }
                    else
                    note.printnotes();
                    System.out.println("plz enter your note:");
                    int nj=scanner.nextInt();
                    note.Delete(nj-1);
                    break;
                case 5:
                    state=false;
                    break;
            }
        }

    }
}