package Lab;
import java.io.*;
import java.net.*;
public class Server {
    public Server(){
        this.start();
    }
    public void start(){
        try(ServerSocket server = new ServerSocket(4444);Socket channel = server.accept();DataInputStream in = new DataInputStream(channel.getInputStream());DataOutputStream out = new DataOutputStream(channel.getOutputStream());){
            System.out.println("start");
            String string="";
            while(true){
                 string+=in.readUTF()+" ";
                out.writeUTF(string);
            }

        } catch (IOException ex) {
            ex.getStackTrace();
        }
        System.out.println("end");
    }
    public static void main(String[] args) {
        Server server=new Server();
        server.start();
    }
}
