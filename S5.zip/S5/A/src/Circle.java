import java.util.Objects;
import static java.lang.Math.pow;

public class Circle extends Shape {
    private static final double PI=3.14;
    private double radius;
    public Circle(double radius){
        this.radius=radius;
    }
    /**
     * to calculate the perimeter of circle
     * @return perimeter
     */
    @Override
    public double CalculatePerimeter(Integer... args) {
        double P=2*PI*radius;
        return P;
    }
    /**
     * to calculate the area of circle
     * @return area
     */
    @Override

    public double CalculateArea(Integer... args) {
        double A= PI*pow(radius,2);
        return A;
    }
    /**
     * to print information of circle
     */
    @Override
    public void draw() {
        System.out.printf("Circle:{ Radius: %.1f   Perimeter: %.2f   Area: %.2f }",radius,CalculatePerimeter(),CalculateArea());
        System.out.println();
    }

    @Override
    public String toString() {
        return "Circle{" +
                "radius=" + radius
               +", perimeter="+CalculatePerimeter()+ ", Area="+CalculateArea()+'}';
    }

    public double getRadius() {
        return radius;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getRadius());
    }
}
