import java.io.*;
import java.net.*;


public class Server {
    public static void main(String[] args) throws Exception {
        ServerSocket server = new ServerSocket(4404);
        while(true) {
            Socket socket = server.accept();
            System.out.println("connected");
            Handler sc=new Handler(socket);
            sc.start();
        }
    }
}

/**
 * class for handle clients
 */
class Handler extends Thread{
    Socket socket;
    public Handler(Socket socket){
        this.socket=socket;
    }

    /**
     * overide method
     */
    public void run(){
        try(DataInputStream input = new DataInputStream(socket.getInputStream()); DataOutputStream output = new DataOutputStream(socket.getOutputStream());){
            while (true){
                String s=input.readUTF();
                output.writeUTF(s);
            }
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
}

