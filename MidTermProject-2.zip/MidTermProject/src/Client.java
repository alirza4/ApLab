//import java.io.*;
//import java.net.Socket;
//import java.util.Scanner;
//public class Client {
////private String name;
////private String rol;
////private boolean alive;
//private Socket socket;
//    public Client(Socket socket) {
//        this.socket=socket;
////        this.name = name;
////        this.rol = rol;
////        alive=true;
//    }
//
//    public Socket getSocket() {
//        return socket;
//    }
////
////    public String getName() {
////        return name;
////    }
////
////    public String getRol() {
////        return rol;
////    }
////
////    public boolean isAlive() {
////        return alive;
////    }
//
////    public void setAlive(boolean alive) {
////        this.alive = alive;
////    }
//    public static void main(String[] args) {
//        Scanner scanner=new Scanner(System.in);
//        try(Socket socket = new Socket("localhost",1664);DataOutputStream output=new DataOutputStream(socket.getOutputStream())){
//            ServHand servcon=new ServHand(socket);
//            new Thread(servcon).start();
//            while(true){
//                String string=scanner.nextLine();
//                if (!socket.getKeepAlive()){
//                    break;
//                }
//                output.writeUTF(string);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//    }
//    class ServHand implements Runnable{
//        private Socket client;
//        private DataInputStream input;
//        public ServHand(Socket client) throws IOException {
//            this.client = client;
//            input = new DataInputStream(client.getInputStream());
//        }
//        @Override
//        public void run() {
//                try {
//                    while (true){
//                    System.out.println(input.readUTF());
//
//                    }
//                } catch (IOException ex) {
//                    System.out.println(ex);
//                }
//            try {
//                input.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
import java.io.*;
import java.net.Socket;
import java.util.Scanner;
public class Client {
    Scanner scanner=new Scanner(System.in);
    public void start(){
        try(Socket socket = new Socket("localhost",1664);DataOutputStream output=new DataOutputStream(socket.getOutputStream())){
            ServHand servcon=new ServHand(socket);
            new Thread(servcon).start();
            while(true){
                String string=scanner.nextLine();
                if (string.equals("over")){
                    break;
                }
                output.writeUTF(string);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Client player=new Client();
        player.start();
    }
}
class ServHand implements Runnable{
    private Socket client;
    private DataInputStream input;
    public ServHand(Socket client) throws IOException {
        this.client = client;
        input = new DataInputStream(client.getInputStream());
    }
    @Override
    public void run() {
        try {
            while (true){
                System.out.println(input.readUTF());

            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
        try {
            input.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
